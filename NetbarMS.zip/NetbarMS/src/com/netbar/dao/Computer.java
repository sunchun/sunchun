package com.netbar.dao;

/**
 * Computer entity. @author MyEclipse Persistence Tools
 */

public class Computer implements java.io.Serializable {

	// Fields

	private Integer computerId;
	private Double price;
	private Integer state;

	// Constructors

	/** default constructor */
	public Computer() {
	}

	/** full constructor */
	public Computer(Integer computerId, Double price, Integer state) {
		this.computerId = computerId;
		this.price = price;
		this.state = state;
	}

	// Property accessors

	public Integer getComputerId() {
		return this.computerId;
	}

	public void setComputerId(Integer computerId) {
		this.computerId = computerId;
	}

	public Double getPrice() {
		return this.price;
	}

	public void setPrice(Double price) {
		this.price = price;
	}

	public Integer getState() {
		return this.state;
	}

	public void setState(Integer state) {
		this.state = state;
	}

}