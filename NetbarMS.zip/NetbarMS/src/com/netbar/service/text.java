package com.netbar.service;

import java.util.Date;

public class text {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		ManageSystem ms = new ManageSystem();
		Date date = new Date();
		ms.landComputer("320125199505301510", 101, date);
		System.out.print(ms.logoutCompter("320125199505301510", 101, date));
		//System.out.print(ms.account(2, 101));
	}

}
