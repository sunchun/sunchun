package com.netbar.GUI;

import java.awt.BorderLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.util.Calendar;

import javax.swing.JFrame;
import javax.swing.JTextField;
import javax.swing.Timer;

public class ClockText extends JTextField implements ActionListener {
	private Timer t;
	Calendar c;

	// private String str;
	public ClockText() {

		super();
		s();
		this.addActionListener(this);
		t.start();
	}

	public ClockText(int i) {
		super(i);
		s();
		this.addActionListener(this);
		t.start();
	}

	private void s() {
		t = new Timer(1000, this);
	}

	public void actionPerformed(ActionEvent e) {
		c = Calendar.getInstance();
		this.setText("" + c.getTime());
	}

	public static void main(String args[]) {
		JFrame f = new JFrame();
		f.setSize(500, 200);
		f.getContentPane().setLayout(new BorderLayout());
		f.getContentPane().add(new ClockText(20), BorderLayout.CENTER);
		f.setVisible(true);
	}
}